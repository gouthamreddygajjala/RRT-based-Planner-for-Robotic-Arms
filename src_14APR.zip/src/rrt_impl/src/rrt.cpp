#include "rrt_impl/rrt.hpp"

namespace rrt_core
{
    RRT::RRT(size_t dof, const std::string &urdf_path) : dof_(dof), collision_checker_(urdf_path), kd_tree_(dof)
    {
        std::random_device rd;
        rng_ = std::mt19937(rd());
        std::cout << "RRT Constructed with DOF: " << dof_ << std::endl;
    }

    void RRT::setStart(const std::vector<double> &q)
    {
        validateConfig(q);

        if (!isCollisionFree(q))
        {
            throw std::runtime_error("Start configuration is in collision");
        }

        q_start_ = q;

        nodes_.clear();
        kd_tree_.clear(); // reset

        nodes_.push_back({q_start_, -1}); // root node
        kd_tree_.insert(q_start_, 0);     // seed with start node
    }

    void RRT::setGoal(const std::vector<double> &q)
    {
        validateConfig(q);

        if (!isCollisionFree(q))
        {
            throw std::runtime_error("Goal configuration is in collision");
        }

        q_goal_ = q;
    }

    void RRT::setJointLimits(const std::vector<double> &lower, const std::vector<double> &upper)
    {
        if (lower.size() != dof_ || upper.size() != dof_)
        {
            throw std::runtime_error("Joint limits size mismatch");
        }

        lower_limits_ = lower;
        upper_limits_ = upper;
    }

    void RRT::setStepSize(double step) { step_size_ = step; }
    void RRT::setGoalBias(double bias) { goal_bias_ = bias; }
    void RRT::setGoalTolerance(double tol) { goal_tolerance_ = tol; }
    void RRT::reserve(size_t n) { nodes_.reserve(n); }

    void RRT::validateConfig(const std::vector<double> &q) const
    {
        if (q.size() != dof_)
        {
            throw std::runtime_error("Configuration DOF mismatch");
        }

        // Optional (but useful): check joint limits if set
        if (!lower_limits_.empty() && !upper_limits_.empty())
        {
            for (size_t i = 0; i < dof_; ++i)
            {
                if (q[i] < lower_limits_[i] || q[i] > upper_limits_[i])
                {
                    throw std::runtime_error("Configuration violates joint limits");
                }
            }
        }
    }

    double RRT::distance(const std::vector<double> &a, const std::vector<double> &b) const // Joint Euclidean distance(not cartesian)
    {
        double sum = 0.0;

        for (size_t i = 0; i < dof_; ++i)
        {
            double d = a[i] - b[i];
            sum += d * d;
        }

        return std::sqrt(sum);
    }

    std::vector<double> RRT::sampleRandomConfig()
    {
        // Probability distribution for goal bias
        std::uniform_real_distribution<double> prob_dist(0.0, 1.0);

        // Goal biasing
        if (prob_dist(rng_) < goal_bias_)
        {
            return q_goal_;
        }

        std::vector<double> q(dof_);

        for (size_t i = 0; i < dof_; ++i)
        {
            std::uniform_real_distribution<double> dist(
                lower_limits_[i],
                upper_limits_[i]);

            q[i] = dist(rng_);
        }

        return q;
    }

    // int RRT::getNearestNode(const std::vector<double> &q)
    // {
    //     double min_dist = std::numeric_limits<double>::max();
    //     int nearest_idx = 0;

    //     for (size_t i = 0; i < nodes_.size(); ++i)
    //     {
    //         double d = distance(nodes_[i].q, q);

    //         if (d < min_dist)
    //         {
    //             min_dist = d;
    //             nearest_idx = static_cast<int>(i);
    //         }
    //     }

    //     return nearest_idx;
    // }

    int RRT::getNearestNode(const std::vector<double> &q)
    {
        return kd_tree_.nearest(q);
    }

    std::vector<double> RRT::steer(const std::vector<double> &q_near, const std::vector<double> &q_rand)
    {
        std::vector<double> q_new(dof_);

        double dist = distance(q_near, q_rand);

        // If already close, just return q_rand
        if (dist < step_size_)
        {
            return q_rand;
        }

        // Move from q_near toward q_rand
        for (size_t i = 0; i < dof_; ++i)
        {
            q_new[i] = q_near[i] + step_size_ * (q_rand[i] - q_near[i]) / dist;
            q_new[i] = std::clamp(q_new[i], lower_limits_[i], upper_limits_[i]);
        }

        return q_new;
    }

    bool RRT::isEdgeCollisionFree(const std::vector<double> &q1,
                                  const std::vector<double> &q2) const
    {
        double dist = distance(q1, q2);

        // Resolution of interpolation (tunable)
        const double resolution = 0.05;

        int steps = static_cast<int>(dist / resolution);

        // Ensure at least one check
        steps = std::max(steps, 1);

        for (int i = 0; i <= steps; ++i)
        {
            double t = static_cast<double>(i) / steps;

            std::vector<double> q_interp(dof_);

            for (size_t j = 0; j < dof_; ++j)
            {
                q_interp[j] = q1[j] + t * (q2[j] - q1[j]);
            }

            if (!isCollisionFree(q_interp))
            {
                return false;
            }
        }

        return true;
    }

    std::vector<std::vector<double>> RRT::shortcutPath(const std::vector<std::vector<double>> &path)
    {
        if (path.size() <= 2)
            return path;

        std::vector<std::vector<double>> smoothed;
        smoothed.push_back(path.front());

        size_t i = 0;
        const size_t max_skip = 3; // never skip more than 3 waypoints at once

        while (i < path.size() - 1)
        {
            // Cap lookahead to max_skip
            size_t j = std::min(i + max_skip, path.size() - 1);

            while (j > i + 1)
            {
                if (isEdgeCollisionFree(path[i], path[j]))
                    break;
                --j;
            }

            smoothed.push_back(path[j]);
            i = j;
        }

        return smoothed;
    }

    std::vector<std::vector<double>> RRT::interpolatePath(const std::vector<std::vector<double>> &path, int num_points) // CUBIC SPLINE INTERPOLATION
    {
        int n = path.size();
        if (n < 2)
            return path;

        // Parameter t: 0 to 1 evenly spaced over waypoints
        std::vector<double> t(n);
        for (int i = 0; i < n; ++i)
            t[i] = static_cast<double>(i) / (n - 1);

        std::vector<std::vector<double>> result(num_points, std::vector<double>(dof_));

        for (size_t j = 0; j < dof_; ++j)
        {
            // Extract this joint's values across waypoints
            std::vector<double> y(n);
            for (int i = 0; i < n; ++i)
                y[i] = path[i][j];

            // Compute cubic spline coefficients (natural spline)
            std::vector<double> h(n - 1), alpha(n - 1);
            for (int i = 0; i < n - 1; ++i)
                h[i] = t[i + 1] - t[i];

            for (int i = 1; i < n - 1; ++i)
                alpha[i] = (3.0 / h[i]) * (y[i + 1] - y[i]) -
                           (3.0 / h[i - 1]) * (y[i] - y[i - 1]);

            std::vector<double> l(n, 1.0), mu(n, 0.0), z(n, 0.0);

            for (int i = 1; i < n - 1; ++i)
            {
                l[i] = 2.0 * (t[i + 1] - t[i - 1]) - h[i - 1] * mu[i - 1];
                mu[i] = h[i] / l[i];
                z[i] = (alpha[i] - h[i - 1] * z[i - 1]) / l[i];
            }

            std::vector<double> c(n, 0.0), b(n - 1), d(n - 1);

            for (int i = n - 2; i >= 0; --i)
            {
                c[i] = z[i] - mu[i] * c[i + 1];
                b[i] = (y[i + 1] - y[i]) / h[i] - h[i] * (c[i + 1] + 2.0 * c[i]) / 3.0;
                d[i] = (c[i + 1] - c[i]) / (3.0 * h[i]);
            }

            // Evaluate spline at num_points
            for (int k = 0; k < num_points; ++k)
            {
                double tk = static_cast<double>(k) / (num_points - 1);

                // Find the segment
                int seg = 0;
                for (int i = 0; i < n - 2; ++i)
                {
                    if (tk >= t[i + 1])
                        seg = i + 1;
                }

                double dt = tk - t[seg];
                result[k][j] = y[seg] +
                               b[seg] * dt +
                               c[seg] * dt * dt +
                               d[seg] * dt * dt * dt;
            }
        }

        return result;
    }

    bool RRT::plan(int max_iter)
    {

        std::cout << "[RRT] Planner parameters:" << std::endl;
        std::cout << "  DOF: " << dof_ << std::endl;
        std::cout << "  Step size: " << step_size_ << std::endl;
        std::cout << "  Goal bias: " << goal_bias_ << std::endl;
        std::cout << "  Goal tolerance: " << goal_tolerance_ << std::endl;
        std::cout << "  Max iterations: " << max_iter << std::endl;

        // Safety checks
        if (q_start_.empty() || q_goal_.empty())
        {
            throw std::runtime_error("Start or Goal not set");
        }

        if (lower_limits_.empty())
        {
            throw std::runtime_error("Joint limits not set");
        }

        goal_index_ = -1;

        for (int i = 0; i < max_iter; ++i)
        {
            // 1. Sample
            auto q_rand = sampleRandomConfig();

            // 2. Nearest
            int nearest_idx = getNearestNode(q_rand);
            const auto &q_near = nodes_[nearest_idx].q;

            // 3. Steer
            auto q_new = steer(q_near, q_rand);

            // 4. Collision (edge check)
            if (!isEdgeCollisionFree(q_near, q_new))
                continue;

            // 5. Add node
            nodes_.push_back({q_new, nearest_idx});
            int new_idx = nodes_.size() - 1;

            kd_tree_.insert(q_new, new_idx); // update KD-tree with new node

            // 6. Goal check
            if (distance(q_new, q_goal_) < goal_tolerance_)
            {
                // Connect goal
                nodes_.push_back({q_goal_, new_idx});
                goal_index_ = nodes_.size() - 1;

                std::cout << "[RRT] Tree size: " << nodes_.size() << std::endl; // tree size at success

                return true; // success
            }
        }

        std::cout << "[RRT] Tree size: " << nodes_.size() << std::endl; // tree size at failure

        return false; // failed
    }

    std::vector<std::vector<double>> RRT::getPath() const
    {
        std::vector<std::vector<double>> path;

        // If planning failed
        if (goal_index_ == -1)
        {
            return path;
        }

        int idx = goal_index_;

        // Backtrack from goal to start
        while (idx != -1)
        {
            path.push_back(nodes_[idx].q);
            idx = nodes_[idx].parent_index;
        }

        // Reverse to get start → goal
        std::reverse(path.begin(), path.end());

        return path;
    }

    double RRT::computePathLength(const std::vector<std::vector<double>> &path, std::vector<Eigen::Vector3d> &tcp_points)
    {
        return collision_checker_.computeCartesianPathLength(path, tcp_points);
    }

    double RRT::checkIK(const geometry_msgs::msg::Pose &pose, std::vector<double> &q_out)
    {
        return collision_checker_.getIK(pose, q_out);
    }

    bool RRT::isCollisionFree(const std::vector<double> &q) const
    {
        if (collision_checker_.isStateValid(q))
        {
            // std::cout << "State is valid" << std::endl;
        }
        else
        {
            std::cout << "State is in collision" << std::endl;
        }
        return collision_checker_.isStateValid(q);
    }

    void RRT::addPrimitive(const std::string &name, collision::PrimitiveType type,
                          const std::vector<double> &params, const Eigen::Isometry3d &pose)
    {
        collision_checker_.addPrimitive(name, type, params, pose);
    }

    void RRT::addMesh(const std::string &name, const std::vector<Eigen::Vector3d> &vertices,
                      const std::vector<std::array<int, 3>> &triangles, const Eigen::Isometry3d &pose)
    {
        collision_checker_.addMesh(name, vertices, triangles, pose);
    }

    bool RRT::removeSceneObject(const std::string &name)
    {
        return collision_checker_.removeSceneObject(name);
    }

    void RRT::clearSceneObjects()
    {
        collision_checker_.clearSceneObjects();
    }

    // void RRT::printSceneObjects() const
    // {
    //     collision_checker_.printSceneObjects();
    // }

    // void RRT::getSceneObjects(std::vector<collision::CheckCollision::SceneObjectInfo> &objects) const
    // {
    //     objects = collision_checker_.getSceneObjects();
    // }

} // namespace rrt_core